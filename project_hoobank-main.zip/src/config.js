const config = {
    API_BASE_URL: 'http://localhost:10000/', // Updated to use the correct URL
  };
  
  export default config;
  